namespace Blog.Models;

public class Postagen
{
    public int Id { get; set; }
    public string? Titulo { get; set; }
    public string? Assunto { get; set; }
    public string? Conteudo { get; set; }
}